/*
 * clase para manejar las obras sociales
 */
package entidades;

/**
 *
 * @author Lautaro
 */
//obraSocial tiene atributos id y obrasocial que almacenan el identificador y el nombre de la obra social, respectivamente.
//Ofrece dos constructores: uno para inicializar los atributos con valores proporcionados y otro para establecer valores predeterminados.
//Métodos get y set para cada atributo que permiten obtener y establecer los valores de los atributos.
//El método toObject() convierte los atributos de la obra social en un arreglo de objetos para posiblemente utilizarlos en otro contexto (quizás para mostrar la información en una interfaz gráfica o realizar operaciones de visualización).
//Hay un método llamado getEspecialidades() que arroja una excepción "Not supported yet" indicando que su implementación aún no está completa.

public class obraSocial {

    private int id;
    private String obrasocial;

    public obraSocial(int id, String obrasocial) {
        this.setId(id);
        this.setObrasocial(obrasocial);
    }

    public obraSocial() {
        this.setId(0);
        this.setObrasocial("");
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getObrasocial() {
        return obrasocial;
    }

    public void setObrasocial(String obrasocial) {
        this.obrasocial = obrasocial;
    }

    public Object[] toObject() {
        Object[] info = new Object[]{getId(),getObrasocial()};
        return info;
    }

    public Object getEspecialidades() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
