/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package etiquetas;

import static clinica.FrmSistema.iconos;

/**
 *
 * @author Lautaro
 */
public class LblObraSocial extends Lbl{
    
    public LblObraSocial(){
        setText("Obra Social:");
        setIcon(iconos.getObraSocial(16));
    }
    
}
