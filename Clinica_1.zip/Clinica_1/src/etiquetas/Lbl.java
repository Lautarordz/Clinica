/*
 * SUPERCLASE PARA ETIQUETAS O JLabel
 */
package etiquetas;

import javax.swing.JLabel;

/**
 *
 * @author Lautaro
 */
public class Lbl extends JLabel{
    
    public Lbl(){
        setText("");
    }
    
}
