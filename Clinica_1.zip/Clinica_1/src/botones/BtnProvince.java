/*
 * Boton Usuario
 */
package botones;

import static clinica.FrmSistema.iconos;


/**
 *
 * @author Lautaro
 */
public class BtnProvince extends Btn{
    
    public BtnProvince(){
        setText("Provincia");
        setIcon(iconos.getProvince(16));
    }
    
}
