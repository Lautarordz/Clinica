/*
 * Boton Usuario
 */
package botones;

import static clinica.FrmSistema.iconos;


/**
 *
 * @author Lautaro
 */
public class BtnUser extends Btn{
    
    public BtnUser(){
        setText("Usuario");
        setIcon(iconos.getUser(16));
    }
    
}
