/*
 * Boton Filtro
 */
package botones;

import static clinica.FrmSistema.iconos;


/**
 *
 * @author Lautaro
 */
public class BtnAcept extends Btn{
    
    public BtnAcept(){
        setText("Aceptar");
        setIcon(iconos.getAcept(16));
    }
    
}
