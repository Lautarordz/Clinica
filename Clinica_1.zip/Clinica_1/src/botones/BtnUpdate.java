/*
 * Boton Salir
 */
package botones;

import static clinica.FrmSistema.iconos;


/**
 *
 * @author Lautaro
 */
public class BtnUpdate extends Btn{
    
    public BtnUpdate(){
        setText("Actualizar");
        setIcon(iconos.getUpdate(16));
    }
    
}
